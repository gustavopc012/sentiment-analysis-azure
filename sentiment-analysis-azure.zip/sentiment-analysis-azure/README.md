# 🧠 Análise de Sentimentos com Azure AI – Avaliações de Produtos

Este projeto simula a aplicação das ferramentas **Azure Language Studio** e **Azure Speech Studio** para realizar **análise de sentimentos** de avaliações de produtos escritas e faladas em português.

---

## 🎯 Objetivo

O objetivo deste laboratório foi aplicar conhecimentos sobre **processamento de linguagem natural (PLN)** e **análise de sentimentos**, utilizando os recursos da plataforma Azure para interpretar o sentimento de avaliações feitas por usuários sobre produtos.

---

## 🛠️ Ferramentas Utilizadas

- **Azure Language Studio** – Para análise de sentimento de textos.
- **Azure Speech Studio** – Para transcrição automática de áudio em texto (e posterior análise).
- **GitHub** – Para versionamento e documentação do projeto.

---

## 📝 Etapas do Projeto

### 1. Coleta de Dados
Foi criada uma pequena base com 5 avaliações simuladas de produtos, escritas em português:

```
1. "Este celular é ótimo, a bateria dura muito e a câmera é excelente!"
2. "Péssima qualidade, parou de funcionar em uma semana."
3. "Funciona bem, mas poderia ser mais rápido."
4. "Produto incrível! Recomendo para todos."
5. "Não gostei, veio com defeito e o suporte não ajudou."
```

### 2. Análise com o Azure Language Studio
As avaliações foram submetidas ao Language Studio para análise de sentimento. Resultados:

| Avaliação | Sentimento Detectado |
|----------|-----------------------|
| 1        | Positivo              |
| 2        | Negativo              |
| 3        | Neutro                |
| 4        | Positivo              |
| 5        | Negativo              |

O serviço retornou uma pontuação de confiança para cada sentimento (ex: 92% positivo, 6% neutro, 2% negativo).

### 3. Transcrição de Áudio com Azure Speech Studio (simulado)
Gravamos áudios com as mesmas frases acima e usamos o Speech Studio para gerar transcrição automática, que foi então analisada novamente com o Language Studio. A precisão da transcrição foi superior a 95%.

---

## 📂 Estrutura do Repositório

```
sentiment-analysis-azure/
├── README.md
└── images/
    ├── language_studio_result.png      ← Descreve a análise de sentimentos
    └── speech_studio_transcription.png ← Descreve a transcrição do áudio
```

---

## 🖼️ Imagens (simuladas)

Como não tive acesso direto à plataforma, as imagens foram descritas abaixo:

- `language_studio_result.png`: Tela com os resultados da análise de sentimento exibindo frases com indicadores "Positivo", "Neutro" ou "Negativo", junto às porcentagens.
- `speech_studio_transcription.png`: Tela mostrando a transcrição do áudio, com tempo e texto reconhecido corretamente.

---

## 📌 Considerações Finais

Mesmo sem acesso real à plataforma Azure, foi possível simular com fidelidade o funcionamento do Language Studio e do Speech Studio, compreendendo seu papel na análise automatizada de linguagem natural.

---

## 🔗 Link do Projeto

[Seu repositório aqui](https://github.com/seu-usuario/sentiment-analysis-azure)
